PyLadies at PyCon 2012!
-----------------------

By `Christine Cheung </blog/author/xtine/>`_ posted Dec. 12, 2011, 7:12
a.m.

We're happy to announce that with the help of the Python Software
Foundation, PyLadies will be making an appearance at
`PyCon <http://us.pycon.org/2012>`_ 2012! We will be exhibiting during
the main portion of conference and will be on hand to help any other
interested PyLadies in joining or starting up their own chapter. We will
soon have details about grants to attend this upcoming PyCon, so stay
tuned!


