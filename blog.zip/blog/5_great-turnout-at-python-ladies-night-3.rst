Great turnout at Python Ladies Night 3
--------------------------------------

By `Audrey Roy </blog/author/audreyr/>`_ posted June 7, 2011, 4:45 a.m.

We had around 14 people come and go throughout the night. It was a
blast!  We talked Python but also other things.  Did you know that there
are enough of us who ride scooters/motorcycles that we could have our
very own PyLadies rally club?

Attendees were mostly Python developer ladies, but also a few gentlemen
of the Python community and possibly one guy who doesn't know Python
(yet ;)  Here are some of us:

`|Python Ladies' Night
3| <http://www.flickr.com/photos/pyladies/5806807107/>`_

Sad that you missed it? Come for the next one! It'll be right after the
PyLadies Hack Session. Even if you can't make it to the event, you can
still join us for drinks afterward.

\*\*SAVE THE DATE\*\* Python Ladies' Night 4 will be on Saturday, June
18 from 8pm onward, at Hollywood Canteen, 1006 Seward St, Los Angeles,
CA 90038.

.. |Python Ladies' Night
3| image:: http://farm4.static.flickr.com/3589/5806807107_2efd305529.jpg
