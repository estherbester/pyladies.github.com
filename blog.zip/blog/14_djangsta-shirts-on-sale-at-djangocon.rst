"Djangsta" shirts on sale at DjangoCon!
---------------------------------------

By `Christine Cheung </blog/author/xtine/>`_ posted Sept. 6, 2011, 12:26
a.m.

These "Djangsta" shirts premiered at DjangoCon to a rousing success and
are selling out quickly! If you are coming to DjangoCon this year, find
a PyLady and get one! Proceeds help PyLadies outreach efforts. Shirt
logo was designed by xtine.

Available: Womens L, Mens S/L

A pre-order form will be available for a reprint run!

|image0| Model: `Jeff Schenck <http://twitter.com/#!/jeffschenck>`_

.. |image0| image:: http://i.imgur.com/7epc8.png
