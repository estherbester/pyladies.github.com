Thank You, Python Software Foundation!
--------------------------------------

By `Audrey Roy </blog/author/audreyr/>`_ posted June 7, 2011, 7:12 a.m.

It's true:

`|Thank you, Python Software Foundation. This means so much to
us.| <http://www.flickr.com/photos/pyladies/5807668432/>`_

We are so incredibly grateful to the PSF for taking a chance and
stepping up to help us in a big way.  We have more to say about this and
how it has impacted us, so stay tuned.  

.. |Thank you, Python Software Foundation. This means so much to
us.| image:: http://farm3.static.flickr.com/2150/5807668432_89bbc150e7.jpg
