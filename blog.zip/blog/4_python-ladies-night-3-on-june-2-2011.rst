Python Ladies' Night 3 on June 2, 2011
--------------------------------------

By `Audrey Roy </blog/author/audreyr/>`_ posted June 2, 2011, 10:42 p.m.

We're looking forward to the upcoming Python Ladies' Night 3 tomorrow,
starting at 9pm.  

All female Python developers are invited to meet up for a night of fun
in downtown LA.  Significant others and friends are welcome, so don't
leave them at home!  

Find us at Seven Grand bar in downtown LA:

`http://www.sevengrand.la <http://www.sevengrand.la/>`_
515 W 7th St, 2nd floor, Los Angeles, CA 90014

Meet us there at 9pm.  We may move the group to other nearby bars as the
night goes on.  

If you think you'll be late, email audreyr@pyladies.com with your cell
phone number, so she can text/call you if the group moves.

How will you find us?  Some of us will be wearing PyLadies t-shirts.
 See you soon!
