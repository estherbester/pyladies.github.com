DjangoCon Sponsorship Program: Results
--------------------------------------

By `Audrey Roy </blog/author/audreyr/>`_ posted Sept. 5, 2011, 10:51
p.m.

Announcing the results of the PyLadies' DjangoCon Sponsorship Program.

$4250 was raised, with 100% of it going to making it possible for female Django developers to attend DjangoCon.  Specifically, excited and passionate developers who would not otherwise have attended (who happen to be women).

Here is a breakdown of how the money was used.  For more details about
this, see our PyLadies / DjangoCon US 2011 Sponsorship Program financial
report (`PDF
download <http://dl.dropbox.com/u/768016/pyladies/financial-reports/PyLadies-DjangoConUS2011-Financial-Report.pdf>`_).

.. figure:: https://docs.google.com/a/pyladies.com/spreadsheet/oimg?key=0AmeI6choQL4JdGpkaGJseGVaNWFBUmNWSUNLM3RRS1E&oid=4&zx=a3qc48tfkn72
   :align: center
   :alt: 

Thank you to the individuals and companies who sponsored the program:

Gold ($3000+)
~~~~~~~~~~~~~

Mozilla

|image0|

Silver ($500+)
~~~~~~~~~~~~~~

Cars.com

.. figure:: http://dl.dropbox.com/u/768016/pyladies/sponsors/cars.com/cars-dot-com.jpg
   :align: center
   :alt: 

Steve Holden / The Open Bastion

.. figure:: http://dl.dropbox.com/u/768016/pyladies/sponsors/the-open-bastion/tob-226x128.png
   :align: center
   :alt: 

Bronze ($150+)
~~~~~~~~~~~~~~

Douglas Philips

Supporter ($50+)
~~~~~~~~~~~~~~~~

Justin and Kristy Fields

Shawn Milochik

.. |image0| image:: http://dl.dropbox.com/u/768016/pyladies/sponsors/mozilla/logo-wordmark-mozilla-300x105.png
